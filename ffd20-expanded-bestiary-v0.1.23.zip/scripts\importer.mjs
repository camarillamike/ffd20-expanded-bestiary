const MODULE_ID = "ffd20-expanded-bestiary";
const MODULE_VERSION = "0.1.23";
const AUTO_IMPORT_SETTING = "autoImportOnUpdate";
const IMPORTED_VERSION_SETTING = "importedSourceVersion";
const MANAGED_PACKS = {
  "ffd20-expanded-bestiary_aberrations": "FFD20 Expanded - Aberrations",
  "ffd20-expanded-bestiary_animals": "FFD20 Expanded - Animals",
  "ffd20-expanded-bestiary_bosses": "FFD20 Expanded - Bosses",
  "ffd20-expanded-bestiary_constructs": "FFD20 Expanded - Constructs",
  "ffd20-expanded-bestiary_dragons": "FFD20 Expanded - Dragons",
  "ffd20-expanded-bestiary_fey": "FFD20 Expanded - Fey",
  "ffd20-expanded-bestiary_humanoids": "FFD20 Expanded - Humanoids",
  "ffd20-expanded-bestiary_magical-beasts": "FFD20 Expanded - Magical Beasts",
  "ffd20-expanded-bestiary_monstrous-humanoids": "FFD20 Expanded - Monstrous Humanoids",
  "ffd20-expanded-bestiary_npcs": "FFD20 Expanded - NPCs",
  "ffd20-expanded-bestiary_oozes": "FFD20 Expanded - Oozes",
  "ffd20-expanded-bestiary_outsiders": "FFD20 Expanded - Outsiders",
  "ffd20-expanded-bestiary_plants": "FFD20 Expanded - Plants",
  "ffd20-expanded-bestiary_undead": "FFD20 Expanded - Undead",
  "ffd20-expanded-bestiary_vermin": "FFD20 Expanded - Vermin"
};
const COMPENDIUM_LOOKUP_TYPES = new Set(["feat", "buff", "class", "race", "spell", "weapon", "equipment", "consumable", "loot", "attack"]);
const REPLACEABLE_GENERATED_FLAGS = [
  "generatedFeat",
  "generatedSpellReference",
  "generatedInventoryItem",
];
const PACKAGE_PREFERENCE = ["ffd20-content", "pf-content-for-ffd20", "ffd20"];

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, AUTO_IMPORT_SETTING, {
    name: "Auto-import bestiary updates",
    hint: "Automatically refresh this module's managed compendium packs when the module source version changes.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });
  game.settings.register(MODULE_ID, IMPORTED_VERSION_SETTING, {
    scope: "world",
    config: false,
    type: String,
    default: "",
  });
});

async function fetchJson(path) {
  const response = await fetch(`modules/${MODULE_ID}/${path}`);
  if (!response.ok) throw new Error(`Failed to load ${path}: ${response.status} ${response.statusText}`);
  return response.json();
}

function normalizeName(value) {
  return String(value ?? "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

function generatedFlags(item) {
  return item.flags?.["ffd20-bestiary-builder"] ?? {};
}

function isReplaceableGeneratedItem(item) {
  const flags = generatedFlags(item);
  return REPLACEABLE_GENERATED_FLAGS.some((flag) => flags[flag]);
}

function lookupTypesForItem(item) {
  const flags = generatedFlags(item);
  if (Array.isArray(flags.lookupTypes) && flags.lookupTypes.length) return flags.lookupTypes;
  return item.type ? [item.type] : [];
}

function lookupSubTypesForItem(item) {
  const flags = generatedFlags(item);
  return Array.isArray(flags.lookupSubTypes) ? flags.lookupSubTypes : [];
}

function entrySubType(entry) {
  return foundry.utils.getProperty(entry, "system.subType") ?? foundry.utils.getProperty(entry, "system.classSubType") ?? "";
}

function packageRank(pack) {
  const packageName = pack.collection?.split(".")[0] ?? pack.metadata?.packageName ?? "";
  const index = PACKAGE_PREFERENCE.indexOf(packageName);
  return index >= 0 ? index : PACKAGE_PREFERENCE.length;
}

async function buildItemLookup() {
  const lookup = new Map();
  const packs = game.packs.filter((pack) => pack.documentName === "Item");
  for (const pack of packs) {
    const metadata = pack.metadata ?? {};
    if (metadata.system && metadata.system !== "ffd20") continue;

    const index = await pack.getIndex({ fields: ["name", "type", "system.subType", "system.classSubType"] });
    for (const entry of index) {
      if (!COMPENDIUM_LOOKUP_TYPES.has(entry.type)) continue;
      const key = normalizeName(entry.name);
      if (!key) continue;
      if (!lookup.has(key)) lookup.set(key, []);
      lookup.get(key).push({ pack, entry });
    }
  }
  return lookup;
}

function findLookupMatch(item, lookup) {
  const requestedTypes = lookupTypesForItem(item);
  const requestedSubTypes = lookupSubTypesForItem(item);
  const candidates = (lookup.get(normalizeName(item.name)) ?? []).filter(({ entry }) => {
    if (requestedTypes.length && !requestedTypes.includes(entry.type)) return false;
    if (requestedSubTypes.length && !requestedSubTypes.includes(entrySubType(entry))) return false;
    return true;
  });
  if (!candidates.length) return null;
  return candidates
    .slice()
    .sort((a, b) => {
      const packageDelta = packageRank(a.pack) - packageRank(b.pack);
      if (packageDelta !== 0) return packageDelta;
      return a.pack.collection.localeCompare(b.pack.collection);
    })[0];
}

function applyPlaceholderDetails(source, item) {
  const flags = generatedFlags(item);
  source._id = item._id;
  source.flags = foundry.utils.mergeObject(source.flags ?? {}, item.flags ?? {}, { inplace: false });
  source.flags[MODULE_ID] = {
    compendiumHydrated: true,
    generatedFallback: item,
  };

  if (flags.generatedInventoryItem && source.system && item.system?.quantity) {
    source.system.quantity = item.system.quantity;
  }
  if (flags.generatedInventoryItem && flags.broken && source.system) {
    source.system.broken = true;
  }
  if (flags.generatedSpellReference && source.system) {
    if (item.system?.spellbook) source.system.spellbook = item.system.spellbook;
    if (Number.isFinite(item.system?.level)) source.system.level = item.system.level;
    if (item.system?.atWill) source.system.atWill = true;
    if (item.system?.preparation?.max) source.system.preparation = item.system.preparation;
    if (item.system?.uses?.per) source.system.uses = foundry.utils.mergeObject(source.system.uses ?? {}, item.system.uses, { inplace: false });
  }

  return source;
}

async function hydrateGeneratedItems(actor, lookup) {
  const hydrated = [];
  const report = [];

  for (const item of actor.items ?? []) {
    if (!isReplaceableGeneratedItem(item)) {
      hydrated.push(item);
      continue;
    }

    const match = findLookupMatch(item, lookup);
    if (!match) {
      hydrated.push(item);
      report.push({ actor: actor.name, item: item.name, type: item.type, status: "generated-fallback" });
      continue;
    }

    const source = applyPlaceholderDetails((await match.pack.getDocument(match.entry._id)).toObject(), item);
    source.flags[MODULE_ID].sourcePack = match.pack.collection;
    source.flags[MODULE_ID].sourceId = match.entry._id;

    hydrated.push(source);
    report.push({ actor: actor.name, item: item.name, status: "compendium", type: match.entry.type, pack: match.pack.collection });
  }

  actor.items = hydrated;
  return report;
}

async function prepareActorsForImport(actors) {
  const lookup = await buildItemLookup();
  const report = [];
  for (const actor of actors) {
    report.push(...(await hydrateGeneratedItems(actor, lookup)));
  }
  console.log("FF D20 Expanded Bestiary | Compendium lookup report", report);
  return actors;
}

function packId(packName) {
  return `${MODULE_ID}.${packName}`;
}

function getManagedPack(packName) {
  const pack = game.packs.get(packId(packName));
  if (!pack) throw new Error(`Compendium pack not found: ${packId(packName)}`);
  return pack;
}

async function unlockPack(pack) {
  if (pack.locked) await pack.configure({ locked: false });
}

async function clearPack(pack) {
  const index = await pack.getIndex({ fields: ["name"] });
  const ids = index.map((entry) => entry._id);
  if (ids.length) await Actor.deleteDocuments(ids, { pack: pack.collection });
  return ids.length;
}

export async function importActors({ clear = true } = {}) {
  if (game.system.id !== "ffd20") {
    throw new Error(`This importer expects the ffd20 system, but the active system is "${game.system.id}".`);
  }
  if (!game.user.isGM) throw new Error("Only a GM can import actors into a compendium.");

  const managedPackNames = Object.keys(MANAGED_PACKS);
  const packs = new Map(managedPackNames.map((name) => [name, getManagedPack(name)]));
  for (const pack of packs.values()) await unlockPack(pack);

  const manifest = await fetchJson("source/actors.json");
  const actorsByPack = new Map();
  const allActors = [];
  for (const entry of manifest.actors) {
    const actor = await fetchJson(`source/actors/${entry.file}`);
    const packName = entry.pack && packs.has(entry.pack) ? entry.pack : managedPackNames[0];
    if (!actorsByPack.has(packName)) actorsByPack.set(packName, []);
    actorsByPack.get(packName).push(actor);
    allActors.push(actor);
  }
  await prepareActorsForImport(allActors);

  let removed = 0;
  if (clear) {
    for (const pack of packs.values()) removed += await clearPack(pack);
  }

  const created = [];
  for (const [packName, actors] of actorsByPack) {
    const pack = packs.get(packName);
    created.push(...(await Actor.createDocuments(actors, { pack: pack.collection })));
  }

  ui.notifications.info(`FFD20 Bestiary import complete: ${created.length} actor(s), ${removed} old actor(s) removed.`);
  console.log("FFD20 Bestiary Generated | Import complete", { created: created.length, removed, packs: [...actorsByPack.keys()] });
  await game.settings.set(MODULE_ID, IMPORTED_VERSION_SETTING, MODULE_VERSION);
  return { created, removed, packs };
}

async function managedPackActorCount() {
  let total = 0;
  for (const packName of Object.keys(MANAGED_PACKS)) {
    const pack = getManagedPack(packName);
    const index = await pack.getIndex({ fields: ["name"] });
    total += index.size;
  }
  return total;
}

async function importActorsIfNeeded({ emptyOnly = false } = {}) {
  if (game.system.id !== "ffd20" || !game.user.isGM) return;
  if (!game.settings.get(MODULE_ID, AUTO_IMPORT_SETTING)) {
    console.log("FF D20 Expanded Bestiary | Automatic import disabled by setting.");
    return;
  }

  let total = 0;
  try {
    total = await managedPackActorCount();
  } catch (error) {
    console.warn("FF D20 Expanded Bestiary | Compendium pack check failed", error);
    return;
  }

  const importedVersion = game.settings.get(MODULE_ID, IMPORTED_VERSION_SETTING) ?? "";
  const shouldImport = total === 0 || (!emptyOnly && importedVersion !== MODULE_VERSION);

  if (!shouldImport) {
    console.log("FF D20 Expanded Bestiary | Managed packs already match packaged source; skipping automatic import.", {
      count: total,
      importedVersion,
      moduleVersion: MODULE_VERSION,
    });
    return;
  }

  try {
    const reason = total === 0 ? "empty-packs" : `source-version-changed:${importedVersion || "never"}->${MODULE_VERSION}`;
    console.log("FF D20 Expanded Bestiary | Automatic import starting.", { reason, count: total });
    await importActors({ clear: total > 0 });
  } catch (error) {
    console.error("FF D20 Expanded Bestiary | Automatic import failed", error);
    ui.notifications.error("FF D20 Expanded Bestiary automatic import failed. See console for details.");
  }
}

async function importActorsIfEmpty() {
  return importActorsIfNeeded({ emptyOnly: true });
}

Hooks.once("ready", async () => {
  globalThis.ffd20ExpandedBestiary = {
    importActors,
    importActorsIfEmpty,
    importActorsIfNeeded,
  };
  console.log("FF D20 Expanded Bestiary | Importer ready. Run: await ffd20ExpandedBestiary.importActors()");
  await importActorsIfNeeded();
});
